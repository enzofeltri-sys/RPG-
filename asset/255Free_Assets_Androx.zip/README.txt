Hey, thank you so much for downloading this pack. I hope you enjoy it. If you have some problem, sugestion, or else, contact me by: 
instagram: @underpixelarted
twitter: @AndroxPixelArt
gmail: anders0nfern4ndez@gmail.com

Thank you so much! :)