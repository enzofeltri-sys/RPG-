<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Road" tilewidth="16" tileheight="16" tilecount="84" columns="6">
 <image source="../../Art/Ground Tileset/Tileset_Road.png" width="96" height="224"/>
 <wangsets>
  <wangset name="Unnamed Set" type="mixed" tile="-1">
   <wangcolor name="Road" color="#00ff00" tile="-1" probability="1"/>
   <wangtile tileid="0" wangid="0,0,0,0,1,0,0,0"/>
   <wangtile tileid="1" wangid="0,0,1,1,1,0,0,0"/>
   <wangtile tileid="2" wangid="0,0,1,1,1,1,1,0"/>
   <wangtile tileid="3" wangid="0,0,0,0,1,1,1,0"/>
   <wangtile tileid="4" wangid="0,0,1,1,1,0,1,0"/>
   <wangtile tileid="5" wangid="1,0,0,0,1,1,1,0"/>
   <wangtile tileid="6" wangid="1,0,0,0,1,0,0,0"/>
   <wangtile tileid="7" wangid="1,1,1,1,1,0,0,0"/>
   <wangtile tileid="8" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="9" wangid="1,0,0,0,1,1,1,1"/>
   <wangtile tileid="10" wangid="1,1,1,0,1,0,0,0"/>
   <wangtile tileid="11" wangid="1,0,1,0,0,0,1,1"/>
   <wangtile tileid="12" wangid="1,0,0,0,0,0,0,0"/>
   <wangtile tileid="13" wangid="1,1,1,0,0,0,0,0"/>
   <wangtile tileid="14" wangid="1,1,1,0,0,0,1,1"/>
   <wangtile tileid="15" wangid="1,0,0,0,0,0,1,1"/>
   <wangtile tileid="16" wangid="1,0,1,1,1,0,0,0"/>
   <wangtile tileid="17" wangid="0,0,1,0,1,1,1,0"/>
   <wangtile tileid="19" wangid="0,0,1,0,0,0,0,0"/>
   <wangtile tileid="20" wangid="0,0,1,0,0,0,1,0"/>
   <wangtile tileid="21" wangid="0,0,0,0,0,0,1,0"/>
   <wangtile tileid="22" wangid="1,1,1,0,0,0,1,0"/>
   <wangtile tileid="23" wangid="1,0,0,0,1,0,1,1"/>
   <wangtile tileid="24" wangid="1,1,1,0,1,1,1,1"/>
   <wangtile tileid="25" wangid="1,1,1,1,1,0,1,1"/>
   <wangtile tileid="26" wangid="0,0,1,0,1,0,0,0"/>
   <wangtile tileid="27" wangid="0,0,0,0,1,0,1,0"/>
   <wangtile tileid="28" wangid="1,0,1,1,1,0,1,0"/>
   <wangtile tileid="29" wangid="1,0,1,0,1,1,1,0"/>
   <wangtile tileid="30" wangid="1,0,1,1,1,1,1,1"/>
   <wangtile tileid="31" wangid="1,1,1,1,1,1,1,0"/>
   <wangtile tileid="32" wangid="1,0,1,0,0,0,0,0"/>
   <wangtile tileid="33" wangid="1,0,0,0,0,0,1,0"/>
   <wangtile tileid="34" wangid="1,1,1,0,1,0,1,0"/>
   <wangtile tileid="35" wangid="1,0,1,0,1,0,1,1"/>
   <wangtile tileid="36" wangid="1,0,1,1,1,1,1,0"/>
   <wangtile tileid="37" wangid="1,0,1,0,1,1,1,1"/>
   <wangtile tileid="38" wangid="1,0,1,0,0,0,1,0"/>
   <wangtile tileid="39" wangid="1,0,1,0,1,0,0,0"/>
   <wangtile tileid="40" wangid="1,1,1,0,1,1,1,0"/>
   <wangtile tileid="41" wangid="1,0,1,1,1,0,1,1"/>
   <wangtile tileid="42" wangid="1,1,1,1,1,0,1,0"/>
   <wangtile tileid="43" wangid="1,1,1,0,1,0,1,1"/>
   <wangtile tileid="44" wangid="1,0,0,0,1,0,1,0"/>
   <wangtile tileid="45" wangid="0,0,1,0,1,0,1,0"/>
   <wangtile tileid="46" wangid="1,0,1,0,1,0,1,0"/>
   <wangtile tileid="48" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="49" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="50" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="54" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="55" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="56" wangid="1,1,1,1,1,1,1,1"/>
   <wangtile tileid="60" wangid="1,1,1,0,0,0,1,1"/>
   <wangtile tileid="61" wangid="1,1,1,0,0,0,1,1"/>
   <wangtile tileid="62" wangid="1,1,1,0,0,0,1,1"/>
   <wangtile tileid="63" wangid="1,0,0,0,1,1,1,1"/>
   <wangtile tileid="64" wangid="1,0,0,0,1,1,1,1"/>
   <wangtile tileid="65" wangid="1,0,0,0,1,1,1,1"/>
   <wangtile tileid="66" wangid="1,1,1,1,1,0,0,0"/>
   <wangtile tileid="67" wangid="1,1,1,1,1,0,0,0"/>
   <wangtile tileid="68" wangid="1,1,1,1,1,0,0,0"/>
   <wangtile tileid="69" wangid="0,0,1,1,1,1,1,0"/>
   <wangtile tileid="70" wangid="0,0,1,1,1,1,1,0"/>
   <wangtile tileid="71" wangid="0,0,1,1,1,1,1,0"/>
  </wangset>
 </wangsets>
</tileset>
